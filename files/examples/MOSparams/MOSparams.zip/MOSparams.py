#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 12 11:40:21 2023

@author: anton
"""

from SLiCAP import *

prj = initProject('Plotting of MOS characteristics') 

import EKVplotsN_V
import EKVplotsN
import EKVplotsP_V
import EKVplotsP
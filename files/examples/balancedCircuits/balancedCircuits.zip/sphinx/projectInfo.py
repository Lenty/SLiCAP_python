# -- Project information ------------------------------------------------------
project   = 'SLiCAP project'
copyright = 'The Author'
author    = 'The Author'
version   = '0.1'
release   = '0.1'

